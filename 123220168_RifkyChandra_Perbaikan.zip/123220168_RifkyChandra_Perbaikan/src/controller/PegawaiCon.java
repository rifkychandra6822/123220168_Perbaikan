/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import Pegawai.ModelTablePegawai;
import Pegawai.Pegawai;
import Pegawai.ModelPegawai;
import java.util.List;
import java.util.ArrayList;
import connector.*;
import view.pegawai;
import javax.swing.JOptionPane;
import Pegawai.InterfacePegawai;
/**
 *
 * @author Hp
 */
public class PegawaiCon {
    pegawai frame;
    InterfacePegawai impdatapegawai;
    List<ModelPegawai> dm;
    
    public PegawaiCon(pegawai frame){
    this.frame = frame;
    impdatapegawai = new Pegawai();
    dm = impdatapegawai.getAll();
    }
    public void isitabel (){
        dm = impdatapegawai.getAll();
        ModelTablePegawai mm = new ModelTablePegawai(dm);
        frame.getTabelPegawai().setModel(mm);
    }
}
