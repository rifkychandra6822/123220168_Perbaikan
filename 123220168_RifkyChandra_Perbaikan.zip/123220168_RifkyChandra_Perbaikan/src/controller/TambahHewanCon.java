/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import Hewan.ModelHewan;
import Hewan.Hewan;
import java.util.List;
import java.util.ArrayList;
import connector.*;
import view.Tambahhewan;
import Hewan.InterfaceHewan;


/**
 *
 * @author Hp
 */
public class TambahHewanCon {
    Tambahhewan frame;
    InterfaceHewan impdatahewan;
    List<ModelHewan> dm;
    
    public TambahHewanCon(Tambahhewan frame){
    this.frame = frame;
    impdatahewan = new Hewan();
    dm = impdatahewan.getAll();
    }
    public void insert(){
     ModelHewan dm = new ModelHewan();
     dm.setNama(frame.getNama().getText());
     dm.setKelas(frame.getKelas().getText());
     dm.setJenisMakanan(frame.getJenis_mkn().getText());
     impdatahewan.insert(dm);
     
    }}
    
