/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import Hewan.ModelTableHewan;
import Hewan.ModelHewan;
import Hewan.Hewan;
import java.util.List;
import java.util.ArrayList;
import connector.*;
import view.hewan;
import javax.swing.JOptionPane;
import Hewan.InterfaceHewan;

/**
 *
 * @author Hp
 */
public class HewanCon {
    hewan frame;
    InterfaceHewan impdatahewan;
    List<ModelHewan> dm;
    
    public HewanCon(hewan frame){
    this.frame = frame;
    impdatahewan = new Hewan();
    dm = impdatahewan.getAll();
    }
    public void isitabel (){
        dm = impdatahewan.getAll();
        ModelTableHewan mm = new ModelTableHewan(dm);
        frame.getTabelhewan().setModel(mm);
    }
    
    public void hapusData(int id) {
         impdatahewan.delete(id);
        
        // Refresh tampilan tabel setelah penghapusan berhasil
        isitabel();
    }
 
    public void updateData(ModelHewan hewan) {
        impdatahewan.update(hewan);
        isitabel(); // Refresh the table data
}

    
}